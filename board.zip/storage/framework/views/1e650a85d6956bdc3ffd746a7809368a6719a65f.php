

<?php $__env->startSection('content'); ?>
<div class="side">
    <span>YOTEI BOARD</span> <i class="fas fa-fw fa-cog"></i>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('lang.edit_status')); ?></div>
               
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="slug" class="slug" value="<?php echo e(Session::get('user_id')); ?>">
                    <div class="table-responsive">                       
                        <table class="table table-bordered text-center" id="" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                            <th style="display: none">
                                Order
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Change
                            </th>
                            <th>
                                Action
                            </th>
                            </tr>
                        </thead>    
                        <tbody>
                            <?php $__currentLoopData = $inits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="display: none">
                                        <?php echo e($item->order); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->status); ?>

                                    </td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                        </tbody>                   
                        <tbody id="sortable">       
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="ui-state-default row1" data-id="<?php echo e($item->id); ?>">
                                    <td style="display: none">
                                        <?php echo e($item->order); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->name); ?>

                                    </td>
                                    <td>
                                        <i class="fa fa-sort"></i>
                                    </td>
                                    <td>                                      
                                        <a href="<?php echo e(route('status_delete', $item->id)); ?>" onclick="return window.confirm('Are you sure?')" class="btn btn-danger mb-2 mr-1  btn-sm btn-delete" data-toggle="tooltip" data-placement="bottom" title=""><i class="fa fa-trash"></i></a>    
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card mt-5">
              
                <div class="card-header"><?php echo e(__('lang.add_status')); ?></div>
                <div class="card-body">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name"></label>
                            <input type="text" name="name" id="name" class="form-control" required>
                        </div>
                        <div class="form-group mt-3">
                            <button class="btn btn-danger form-control"><?php echo e(__('lang.submit')); ?></button>
                        </div>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_script'); ?>
    <script>
        $(document).ready(function(){
            $( "#sortable" ).sortable({
                items: "tr",
                cursor: 'move',
                opacity: 0.6,
                update:function(){
                    sortOrderToServer();
                }
            });

            function sortOrderToServer(){
                var order = [];
                var token = $('meta[name="csrf-token"]').attr('content');
                $('tr.row1').each(function(index,element) {
                    order.push({
                        id: $(this).attr('data-id'),
                        position: index+1
                    });
                });
                
                $.ajax({
                    type: "POST", 
                    dataType: "json", 
                    url: "<?php echo e(route('status_store', ['slug'])); ?>",
                    data: {
                        order: order,
                        _token: token
                    },
                    success: function(response) {
                        if (response.status == "success") {
                        console.log(response);
                        } else {
                        console.log(response);
                        }
                    }
                });
            }
        });
    </script>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2020-08\24\board\resources\views/status/editStatus.blade.php ENDPATH**/ ?>