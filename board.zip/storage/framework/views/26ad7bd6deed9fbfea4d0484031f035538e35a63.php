

<?php $__env->startSection('content'); ?>
<div class="side">
    <span>YOTEI BOARD</span> <i class="fas fa-fw fa-cog"></i>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">STATUS</div>
                <div class="card-body">
                    <div class="panel_01">
                        I am meeting now.    
                    </div>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-header">NOTE</div>
                <div class="card-body">
                    <div class="panel">
                        I am busy today, so please email to me.
                        <br>
                        <br>
                        <br>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2020-08\24\board\resources\views/auth/nonAuth.blade.php ENDPATH**/ ?>