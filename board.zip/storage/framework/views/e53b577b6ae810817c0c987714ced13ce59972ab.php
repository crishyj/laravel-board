<?php $__env->startSection('content'); ?>
<div class="side">
    <span>YOTEI BOARD</span> <i class="fas fa-fw fa-cog"></i>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('lang.make_board')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <div class="privacy py-2 px-2">
                                Privacy text will be insert here
                                <br>
                                <br>
                            </div>
                        </div>                       

                        <div class="form-group">
                            <label for="default_status"><?php echo e(__('lang.default_status')); ?></label>

                            <div class="stauts_panel mt-3">
                                <?php echo e(__('lang.init1')); ?>

                            </div>

                            <div class="stauts_panel mt-3">
                                <?php echo e(__('lang.init2')); ?>

                            </div>

                            <div class="stauts_panel mt-3">
                                <?php echo e(__('lang.init3')); ?>

                            </div>
                        </div>

                       
                        <div class="form-group">
                            <label for="password" class="col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-danger form-control">
                                <?php echo e(__('lang.create')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jpelnp97s4gg/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>