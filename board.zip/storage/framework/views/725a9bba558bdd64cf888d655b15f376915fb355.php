

<?php $__env->startSection('content'); ?>
<div class="side">
    <a href="<?php echo e(route('status_index', Session::get('user_id'))); ?>"> <span>YOTEI BOARD</span> <i class="fas fa-fw fa-cog"></i> </a>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="slug" class="slug" value="<?php echo e(Session::get('user_id')); ?>">                 

                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mt-3">
                            <label for="description"><?php echo e(__('lang.update_board')); ?></label>
                            <textarea name="description" id="description" cols="30" rows="10" class="form-control"><?php echo e($description); ?></textarea>
                            
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-new"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="form-group mt-3">
                            <button class="btn btn-danger form-control"><?php echo e(__('lang.submit')); ?></button>
                        </div>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('after_script'); ?>
    <script>
        $(document).ready(function(){
            $('.navbar-brand').css('display', 'none');
        });
    </script>
    
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2020-08\24\board\resources\views/status/editBoard.blade.php ENDPATH**/ ?>