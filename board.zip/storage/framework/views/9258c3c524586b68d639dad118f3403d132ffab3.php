

<?php $__env->startSection('content'); ?>
<div class="side">
    <span>YOTEI BOARD</span> <i class="fas fa-fw fa-cog"></i>
</div>
<div class="container">  
     
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="form-group board_panel">
                        <label for="url"><?php echo e(__('lang.url')); ?></label>
                        <input type="text" name="" id="" class="form-control" readonly value= <?php echo e(Auth::user()->slugUrl); ?>>
                    </div>
                </div>
            </div>
  
            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-group board_panel">
                        <label for=""><?php echo e(__('lang.update_status')); ?></label>
                        <select name="update_status" id="update_status" class="form-control">    

                            <?php $__empty_1 = true; $__currentLoopData = $selecteds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>

                            <?php $__currentLoopData = $inits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=""><?php echo e($item->status); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>


            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-group board_panel">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="<?php echo e(route('status_edit', Session::get('user_id'))); ?>">
                                    <button class="btn btn-danger form-control"><?php echo e(__('lang.edit_status')); ?></button>
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('board_edit', Session::get('user_id'))); ?>">
                                    <button class="btn btn-danger form-control"><?php echo e(__('lang.edit_board')); ?></button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-group board_panel">
                        <a href="/logout">
                            <button class="btn btn_success1 form-control mt-3">
                                <?php echo e(__('lang.logout')); ?>

                            </button>
                        </a>
                    </div>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-group board_panel">
                        <a href="<?php echo e(route('user_delete', Session::get('user_id'))); ?>">
                            <button class="btn btn_success1 form-control mt-3">
                                <?php echo e(__('lang.delete')); ?>

                            </button>
                        </a>                        
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('after_script'); ?>
    <script>
        $(document).ready(function(){
            $('#update_status').change(function(){
                let id = $(this).val();
                var token = $('meta[name="csrf-token"]').attr('content');

                if(id != ''){
                    var form_data =new FormData();
                    form_data.append('_token', token);
                    form_data.append('id', id);
                    
                    $.ajax({
                        type: 'POST',
                        dataType: 'json',
                        data: form_data,
                        cache: false,
                        contentType: false,
                        processData: false,
                        url: "<?php echo e(route('status_upate', ['slug'])); ?>",                  
                        success: function(response) {
                            if (response == "success") {
                                window.location.reload();      
                            } else {
                            console.log(response);
                            }
                        }
                    });
                }
              
            });
        });
    </script>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jpelnp97s4gg/public_html/resources/views/status/index.blade.php ENDPATH**/ ?>