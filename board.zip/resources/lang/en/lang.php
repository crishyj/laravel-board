<?php

return [ 
    'description' => 'Description',
    'init1' => 'In a meeting.',
    'init2' => 'I am on the phone.',
    'init3' => 'I am available.',
    'make_board' => 'Make Board',
    'default_status' => 'Default Status',
    'create' => 'Create',
    'slug' => 'Please Input Your Board URL',
    'url' => 'URL',
    'update_status' => 'UPDATE STATUS',
    'edit_status' => 'EDIT STATUS',
    'edit_board' => 'EDIT BOARD',
    'logout' => 'LOGOUT',
    'delete' => 'DELETE',
    'add_status' => 'ADD STATUS',
    'submit' => 'SUBMIT',
    'update_board' => 'UPDATE BOARD',
];
